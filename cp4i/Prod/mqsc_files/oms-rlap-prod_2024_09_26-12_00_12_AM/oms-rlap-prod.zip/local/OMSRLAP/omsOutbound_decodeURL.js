var sm = require("service-metadata");
var inboundURI = sm.getVar('var://service/URI');
//console.log(inboundURI);
var encodedURI =inboundURI.substring(13);
//console.log(encodedURI);
var decodedURL = decodeURIComponent(encodedURI);
//console.log(decodedURL);

var outboundURL = 'https://' + decodedURL;
//console.log(outboundURL);
		sm.setVar('var://service/routing-url', outboundURL);
		
