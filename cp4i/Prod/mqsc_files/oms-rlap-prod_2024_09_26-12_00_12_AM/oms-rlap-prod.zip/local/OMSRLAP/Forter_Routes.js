var hm = require('header-metadata');
var sm = require('service-metadata');
var fs = require('fs');
var merchantName = '';
var siteID = '';
var secretKey = '';
var OrderId = hm.current.get('OrderId');
var domainName = sm.getVar('var://service/domain-name');

/* Read SellerOrganizationCode from Request body */
session.input.readAsJSON(function (error, jsonPayload) {
	if (error) {
		console.log("***Inside jsonPayload error");
		throw error;
	} else {
		merchantName = jsonPayload.additionalInformation.merchant.merchantName;
		console.log("***Inside merchantName" + merchantName);
	};
	
	
	if (domainName == 'oms-rlap-prod') {
		if (merchantName == 'RalphLaurenAU') {
			siteID = '57483765d8cd';
			secretKey = 'Basic ZDgxZWQ2YzlhYjdmOWVmOTkzZWVkY2Y4OGYyNGVmZmM5NWQyNzUxNDo=';
			console.log("***Inside RalphLaurenAU" + merchantName + ' ' + siteID + ' ' + secretKey);
			hm.current. set ('api-version', '2.0'); 
		} else if (merchantName == 'RalphLaurenKR') {
			siteID = '6841326e563d';
			secretKey = 'Basic NWZjNDdiYzE4ZjNkZWE0YzU0MzIyYjUyMmM4YWIxMzE0YTE4YjcyNjo=';
			hm.current.set ('api-version', '2.1');
		} else if (merchantName == 'RalphLaurenTW') {
			siteID = 'ca8ff3ac82c3';
			secretKey = 'Basic MDJjNDA0NmZlMjVmZTY3MDU5NmE4ODY4NWQ4YTM3ZjkzYjA4MzcyYzo=';
			hm.current.set ('api-version', '2.2');
		}else if (merchantName == 'RalphLaurenSG') {
			siteID = '1ee283c3c4f2';
			secretKey = 'Basic M2UxNTlmNmQ3ZjJlYjdhOGM5MTY4NmMyYzNmZDVkM2E5ODkwNjhkODo=';
			hm.current.set ('api-version', '2.0');
		}else if (merchantName == 'RalphLaurenMY') {
			siteID = 'e6a8d5a2e64a';
			secretKey = 'Basic NGExOTc3MDBiZGEwODg0ZTliYWE1ODMxZWU0N2I1NzI3MjNhMzQ0Yjo=';
			hm.current.set ('api-version', '2.1');
		}else {
			console.log("***No merchantName" + merchantName + ' ' + siteID + ' ' + secretKey);
			throw error;
		}
	} else if (domainName == 'oms-rlap-qa') {
		if (merchantName == 'RalphLaurenAU') {
			siteID = 'c92fcd894263';
			secretKey = 'Basic MjFkOWQ3NTgyYTMwZDdjZWU3ZGNkZjg0M2RhMzQxNWU1YjA1OWYzMTo=';
			console.log("***Inside RalphLaurenAU" + merchantName + ' ' + siteID + ' ' + secretKey);
			hm.current.set('api-version', '2.0');
		} else if (merchantName == 'RalphLaurenKR') {
			siteID = '0b4b3f582276';
			secretKey = 'Basic NDgzYzkzMjdmOWM0ODRlODEyMzA3NGYzN2FjOWRhY2UwN2Q5OTNlYjo=';
			hm.current.set('api-version', '2.0');
		}else if (merchantName == 'RalphLaurenTW') {
			siteID = 'd00e10ff31d8';
			secretKey = 'Basic N2NkOGJiZGVjOGZlMjhmOTVmYWE5YTQ1MzE3MTc4YjA2NzdjNWQzZTo=';
			hm.current.set('api-version', '2.0');
		}else if (merchantName == 'RalphLaurenMY') {
			siteID = '4525c640a517';
			secretKey = 'Basic ZDNkNThhZTU0OWRiMTMzZmFhNmQ4NTk4NzY4MjE4MTg2NmQ2MjU3YTo=';
			hm.current.set('api-version', '2.0');
		}else if (merchantName == 'RalphLaurenSG') {
			siteID = '17680afa42fa';
			secretKey = 'Basic NWYxZmFlZGM0ZmZjMWY4NDZmNjRiNWY4ZTE2MDE0OWFiNTRiZmEwMjo=';
			hm.current.set('api-version', '2.0');
		}else {
			console.log("***No merchantName" + merchantName + ' ' + siteID + ' ' + secretKey);
			throw error;
		}
	} else {
		session.output.write("Incorrect Domain");
		throw error;
	}
	
	hm.current. set ('x-forter-siteid', siteID);
	hm.current. set ('Authorization', secretKey);
	
	
	if (OrderId.length > 0) {
		session.output.write(jsonPayload);
		var RoutingURL = 'https://api.forter-secure.com/v2/status/' + OrderId;
		sm.setVar('var://service/routing-url', RoutingURL);
	}
});